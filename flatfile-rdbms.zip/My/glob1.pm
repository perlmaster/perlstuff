#!/usr/perl5/bin/perl -w

package My::Myglobalvars;
use strict;

BEGIN {
	use Exporter();

	@My::Myglobalvars::ISA		= qw(Exporter);
	@My::Myglobalvars::EXPORT	= qw();
	@My::Myglobalvars::EXPORT_OK	= qw($field_separator $database_dir $backup_extension
										%system_tables);
}

use vars qw($field_separator $database_dir $backup_extension
			%system_tables);

sub init_globals
{
	$field_separator = "\006";
	$backup_extension = ".bak";
	$database_dir = "";

	return 0;
}

1;
