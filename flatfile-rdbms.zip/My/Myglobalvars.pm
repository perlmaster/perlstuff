#!/usr/perl5/bin/perl -w

######################################################################
#
# File      : My/Myglobalvars.pm
#
# Author    : Barry Kimelman
#
# Created   : August 13, 2006
#
# Purpose   : Declaration of global variables.
#
######################################################################

package My::Myglobalvars;
use strict;

BEGIN {
	use Exporter();

	@My::Myglobalvars::ISA		= qw(Exporter);
	@My::Myglobalvars::EXPORT	= qw();
	@My::Myglobalvars::EXPORT_OK	= qw($field_separator $database_dir $backup_extension
								%system_tables %valid_data_types %numeric_data_types
								%valid_comparison_operators $rdbms_dirname $systables_file
								$systables_file_path @systables_entries %systables_hash
								$systables_table_id $max_table_id $num_systables_columns
								$systables_tablename_column $systables_filename_column
								$systables_table_id_column $systables_rectotal_column
								$systables_coltotal_column $syscols_file $syscols_file_path
								@syscols_entries $syscols_table_id $max_col_id $syscols_table_id_column
								$syscols_colname_column $syscols_col_id_column
								$syscols_datatype_column $num_syscols_columns
								%data_quotes $errmsg $mainwin $listbox_font $listbox_background_color
								$button_font $button_background_color $label_font $label_background_color
								$text_font $dialog_font $frame_background_color $window_background_color
								%default_fonts $session_start_clock $session_start_time
								@session_command_history $tempdir $activity_log_file
								$activity_log_file_path %validation_functions $debug_flag);
}

use vars qw($field_separator $database_dir $backup_extension
			%system_tables %valid_data_types %numeric_data_types
			%valid_comparison_operators $rdbms_dirname $systables_file
			$systables_file_path @systables_entries %systables_hash
			$systables_table_id $max_table_id $num_systables_columns
			$systables_tablename_column $systables_filename_column
			$systables_table_id_column $systables_rectotal_column
			$systables_coltotal_column $syscols_file $syscols_file_path
			@syscols_entries $syscols_table_id $max_col_id $syscols_table_id_column
			$syscols_colname_column $syscols_col_id_column
			$syscols_datatype_column $num_syscols_columns
			%data_quotes $errmsg $mainwin $listbox_font $listbox_background_color
			$button_font $button_background_color $label_font $label_background_color
			$text_font $dialog_font $frame_background_color $window_background_color
			%default_fonts $session_start_clock $session_start_time @session_command_history
			$tempdir $activity_log_file $activity_log_file_path %validation_functions
			$debug_flag);

sub init_globals
{
	$debug_flag = 1;
	$field_separator = "\006";
	$backup_extension = ".bak";
	%system_tables = ( "systables" => 0 , "syscols" => 1 );
	%valid_data_types = ( "int" => 0 , "float" => 1 , "string" => 2 ,
							"timedate" => 3 , "date" => 4 , "time" => 5 );
	%numeric_data_types = ( "int" => 0 , "float" => 1 );
	%valid_comparison_operators = ( "LIKE" => ";string;" ,
				"UNLIKE" => ";string;" ,
				"EQ" => "*" , "NE" => "*" ,
				"GT" => ";int;float;timedate;date;time;" ,
				"LT" => ";int;float;timedate;date;time;" ,
				"LE" => ";int;float;timedate;date;time;" ,
				"GE" => ";int;float;timedate;date;time;"
			) ;
	$systables_file = "systables.txt";
	$systables_table_id = 0;
	$max_table_id = -1;
	$num_systables_columns = 10;
	$systables_tablename_column = 0;
	$systables_filename_column = 1;
	$systables_table_id_column = 2;
	$systables_rectotal_column = 6;
	$systables_coltotal_column = 9;
	$syscols_file = "syscols.txt";
	$syscols_table_id = 1;
	$max_col_id = -1;
	$syscols_table_id_column = 0;
	$syscols_colname_column = 1;
	$syscols_col_id_column = 2;
	$syscols_datatype_column = 3;
	$num_syscols_columns = 9;
	%data_quotes = ( '"' => '"' , "'" => "'" , '<' => '>' );
	$listbox_font = "Courier 12 bold";
	$listbox_background_color = "#87CEFA"; # Light Sky Blue
	$button_font = "Courier 11 bold";
	$button_background_color = 'gold';
	$label_font = "Courier 12 bold";
	$label_background_color = 'red';
	$text_font = "Courier 12 bold";
	$dialog_font = "Courier 10 bold";
	$window_background_color = 'orange';
	%default_fonts = ( "listbox_font" => "Courier 12 bold" ,
			"listbox_background_color" => "#87CEFA" , # Light Sky Blue
			"button_font" => "Courier 11 bold" ,
			"button_background_color" => "gold" ,
			"label_font" => "Courier 12 bold" ,
			"label_background_color" => "red" ,
			"text_font" => "Courier 12 bold" ,
			"dialog_font" => "Courier 10 bold" ,
			"window_background_color" => "orange",
			"frame_background_color" => "orange"
	) ;
	$activity_log_file = "activity_log.txt";
	%validation_functions = ( "int" => \&validate_int , "float" => \&validate_float ,
						"string" => \&validate_string , "timedate" => \&validate_timedate ,
						"time" => \&validate_time , "date" => \&validate_date );
	return 0;
}

1;
